import '../scss/app.scss';
import step2 from  '../images/2_step.jpg';
import step3 from  '../images/3_step.jpg';
import step4 from  '../images/4_step.jpg';
//Arrow Frequently Questions
const questions = document.querySelectorAll('.question');
questions.forEach((question) => {
  question.onclick = () => {
    if(question.classList.contains('openQuestion')) {
      question.classList.remove('openQuestion');
      question.removeAttribute('style');
    } else {
      question.classList.add('openQuestion');
      setTimeout(() => {
        question.style.height = question.offsetHeight+"px";
      },100)
    }
  }
});
//Slider How It Works
let index = 0;
const sliders = document.querySelectorAll('.works-listItem');
sliders.forEach((slider, key) => {
  slider.onclick = () => {
    index = key;
    openImage(slider);
  };
});
//Open Image Slider
function openImage(item) {
  let srcImage = item.getAttribute('data-src');
  if(!item.classList.contains('activeOpen')) {
    // index = key;
    const imageMedia = document.querySelector('.works-imageMedia');
    imageMedia.style.opacity = .5;
    imageMedia.style.transform = 'translateX(-5px)';
    sliders.forEach((slider) => {
      slider.classList.remove('activeOpen');
    });
    item.classList.add('activeOpen');
    setTimeout(() => {
      imageMedia.src = srcImage;
      imageMedia.style.opacity = 1;
      imageMedia.style.transform = 'translateX(0)';
    },300)
  }
}
function autoPlay() {
  index++;
  index = (index > sliders.length) ? 1 : index;
  openImage(sliders[index-1]);
}
//Autoplay
let playDestop = setInterval(() => {
  autoPlay();
}, 2000);
let playMobie;
//Responsive Css
let contactForm = document.querySelector('.contact_form');
let reason = document.querySelector('.reason');

function responsive() {
  if( window.innerWidth <= 768) {
    reason.style.marginTop = (contactForm.offsetHeight-20) + "px";
  }
  const titleWorks = document.querySelector('h4.title-items');
  const descriptionWorks = document.querySelector('p.description-items');
  if (window.innerWidth <= 599) {
    let title = document.createElement('h4');
    let description = document.createElement('p');
    let workList = document.querySelector('.works-infomation');
    title.className = 'title-items';
    description.className = 'description-items';
    if(!titleWorks && !descriptionWorks) {
      workList.appendChild(title);
      workList.appendChild(description);
      title.textContent = sliders[0].children[0].textContent;
      description.textContent = sliders[0].children[1].textContent;
      clearInterval(playDestop);
      playMobie = setInterval(() => {
        index++;
        index = (index > sliders.length) ? 1 : index;
        openImage(sliders[index-1]);
        title.style.opacity = '0';
        title.style.transform = 'translateX(12px)';
        description.style.opacity = '0';
        description.style.transform = 'translateX(12px)';
        setTimeout(() => {
          title.style.opacity = '1';
          title.style.transform = 'translateX(0)';
          description.style.opacity = '1';
          description.style.transform = 'translateX(0)';
          title.textContent = sliders[index-1].children[0].textContent;
          description.textContent = sliders[index-1].children[1].textContent;
        },300)
      }, 2000);
    }
  } else {
    if(titleWorks && descriptionWorks) {
      titleWorks.remove();
      descriptionWorks.remove();
      clearInterval(playMobie)
      playDestop = setInterval(() => {
        autoPlay();
      }, 2000);
    }
  }
}
window.onload = () => {
  responsive();
};
window.onresize = () => {
  responsive();
};